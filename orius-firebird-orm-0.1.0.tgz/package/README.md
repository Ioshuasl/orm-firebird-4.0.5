# @orius/firebird-orm

Sequelize-like ORM for Firebird extracted from the Orius project.

## Build

```bash
npm run build
```

This compiles the ORM source from `src/orm` into `packages/orm/dist`.

## Local Smoke Test

From repository root:

```bash
npm run build:orm
```

## Publish

From repository root:

```bash
cd packages/orm
npm publish --access public
```

If using a private scope/registry, adjust publish flags accordingly.
